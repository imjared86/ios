//
//  ViewController.swift
//  EggTimer
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit

class ViewController: UIViewController {
    


}
