//
//  ViewController.swift
//  Dicee-iOS13
//
//  Created by Angela Yu on 11/06/2019.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstDiceImageView: UIImageView!
    @IBOutlet weak var secondDiceImageView: UIImageView!
    
    let diceImages = [UIImage(named: "DiceOne"), UIImage(named: "DiceTwo"), UIImage(named: "DiceThree"), UIImage(named: "DiceFour"), UIImage(named: "DiceFive"), UIImage(named: "DiceSix")]
    
    var leftDiceIndex = 0
    var rightDiceIndex = 5
    
    override func viewDidLoad() {
        super.viewDidLoad()        
        //firstDiceImageView.image = UIImage(named: "DiceTwo")
        
        //Challenge
        //secondDiceImageView.image = UIImage(named: "DiceThree")
    }

    @IBAction func rollButtonPressed(_ sender: UIButton) {
        print("roll button has been pressed!")
        
//        firstDiceImageView.image = diceImages[leftDiceIndex]
//        leftDiceIndex = leftDiceIndex + 1
//
//        //Challenge
//        secondDiceImageView.image = diceImages[rightDiceIndex]
//        rightDiceIndex = rightDiceIndex - 1
        
        firstDiceImageView.image = diceImages[Int.random(in: 0...5)]
        secondDiceImageView.image = diceImages.randomElement()!
    }
    
}

