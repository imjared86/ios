//
//  WeatherManager.swift
//  Clima
//
//  Created by Jared Chen on 2024/3/21.
//
import Foundation

protocol WeatherManagerDelegate {
    func didUpdateWeather(_ weather: WeatherModel)
    func didFailWithError(_ error: Error)
}

struct WeatherManager{
    let weatherURL = "https://api.openweathermap.org/data/2.5/weather?appid=11ded175e6fc6a42d5263910c6b70fce&units=metric"
    
    //var vc: WeatherViewController?
    var delegate: WeatherManagerDelegate?
    
    func fetchWeather(lat: Double, lon: Double){
        let urlString = "\(weatherURL)&lat=\(lat)&lon=\(lon)"
        performRequest(urlString: urlString.trimmingCharacters(in: .whitespaces))
    }
    
    func fetchWeather(cityName: String) {
        let urlString = "\(weatherURL)&q=\(cityName)"
        
        //Call API
        print(urlString)
        performRequest(urlString: urlString.trimmingCharacters(in: .whitespaces)) //remove whitespaces in the url
        
    }
    
    func performRequest(urlString: String){
        //1. Create URL, returns an optional URL
        if let url = URL(string: urlString) {
            //2. Create URL Session
            let session = URLSession(configuration: .default)
            
            //3. Give the session a task
            //completionHandler is the function to handle the response
            //once the task is completed, it will automatically trigger the handle function and pass parameter.
            //let task = session.dataTask(with: url, completionHandler: handle(data:response:error:))
            let task = session.dataTask(with: url) {(data, response, error) in
                if error != nil {
                    delegate?.didFailWithError(error!)
                    return
                }
                
                if let safeData = data {
//                    let dataString = String(data: safeData, encoding: .utf8)
//                    print(dataString!)
                    if let weather = parseJSON(weatherData: safeData) {
                        //How to pass weather model to view controller to update UI
                        
                        //Two problems
                        //1. weatherVC is not the same object of current VC which renders the app.
                        //let weatherVC = WeatherViewController()
                        //weatherVC.didUpdateWeather(weather)
                        
                        //2. WeatherManager will only work with WeatherViewController, no more flexibility.
                        //vc?.didUpdateWeather(weather)
                        
                        //use delegate design pattern
                        delegate?.didUpdateWeather(weather)
                    }
                }
            }
            
            //4. Start the task
            task.resume()
        }
    }
    
    func parseJSON(weatherData: Data) -> WeatherModel?{
        let decoder = JSONDecoder()
        do{
            let decodedData = try decoder.decode(WeatherData.self, from: weatherData)
            
            let name = decodedData.name
            let temp = decodedData.main.temp
            let id = decodedData.weather[0].id
            
            let weather = WeatherModel(conditionId: id, cityName: name, temperature: temp)
            
            return weather
            //weather.getConditionName() - Use computed property instead
        }catch{
            delegate?.didFailWithError(error)
            return nil
        }
    }
    
//    func getConditionName(weatherId: Int) -> String {
//        switch(weatherId){
//        case 200...232:
//            return "cloud.bolt"
//        case 300...321:
//            return "cloud.drizzle"
//        case 500...531:
//            return "cloud.rain"
//        case 600...622:
//            return "cloud.snow"
//        case 701...781:
//            return "cloud.fog"
//        case 800:
//            return "sun.max"
//        case 801...804:
//            return "cloud.bolt"
//        default:
//            return "cloud"
//        }
//    }
//    func handle(data:Data?, response:URLResponse?, error:Error?) -> Void{
//        if error != nil {
//            print(error!)
//            return
//        }
//
//        if let safeData = data {
//            //print(safeData) - Wont be able to see the data, we should convert to String first
//
//            let dataString = String(data: safeData, encoding: .utf8)
//            print(dataString!)
//        }
//    }
}
