//
//  BMI.swift
//  BMI Calculator
//
//  Created by Jared Chen on 2024/3/20.
//
import UIKit

struct BMI{
    var value: Float
    var advice: String
    var color: UIColor
}
