//
//  ViewController.swift
//  BMI Calculator
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var heightLabel: UILabel!
    @IBOutlet weak var weightLabel: UILabel!
    
    @IBOutlet weak var heightSlider: UISlider!
    @IBOutlet weak var weightSlider: UISlider!
    
    //var bmiValue = "0.0"
    var bmiBrain = BMIBrain()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func heightChanged(_ sender: UISlider) {
        print("height is \(sender.value)")
        
        let height = String(format: "%.2f", sender.value)
        heightLabel.text = "\(height)m"
    }
    
    @IBAction func weightChanged(_ sender: UISlider) {
        print("weight is \(sender.value)")
        
        let weight = String(format: "%.0f", sender.value)
        weightLabel.text = "\(weight)Kg"
    }
    
    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        //let bmi = weightSlider.value / pow(heightSlider.value, 2)
        
        //bmiValue = String(format: "%.1f", bmi)
        
        bmiBrain.calculateBMI(height: heightSlider.value, weight: weightSlider.value)
        
//        let secondVC = SecondViewController()
//        secondVC.bmiValue = String(format: "%.1f", bmi)
//
//        self.present(secondVC, animated: true)
        self.performSegue(withIdentifier: "goToResult", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "goToResult" {
            let resultVC = segue.destination as! ResultViewController
            //resultViewController.bmiValue = self.bmiValue
            resultVC.bmiValue = self.bmiBrain.getBMIValue()
            resultVC.bmiAdvice = self.bmiBrain.getBMIAdvice()
            resultVC.bmiColor = self.bmiBrain.getBMIColor()
        }
        
        
    }
}

