//
//  BMIBrain.swift
//  BMI Calculator
//
//  Created by Jared Chen on 2024/3/20.
//
import UIKit

struct BMIBrain
{
    //var bmiValue:Float?
    var bmi: BMI?
    
    mutating func calculateBMI(height: Float, weight: Float) {
        let bmiValue = weight / (height * height)
        
        if bmiValue < 18.5 {
            bmi = BMI(value: bmiValue, advice: "EAT MORE SNACKS!", color: UIColor.blue)
        }else if bmiValue < 24.9 {
            bmi = BMI(value: bmiValue, advice: "Fit AS FIDDLE!", color: UIColor.green)
        }else{
            bmi = BMI(value: bmiValue, advice: "EAT LESS PIES!", color: UIColor.red)
        }
    }
    
    func getBMIValue() -> String{
        //Check for nil value
//        if(bmiValue != nil){
//            return String(format: "%.1f", bmiValue!)
//        }
        
        //Optional Binding
//        if let bmi = bmiValue {
//            return String(format: "%.1f", bmi)
//        }else{
//            return "0.0"
//        }
        
        //Nil coalescing Operator
        return String(format: "%.1f", bmi?.value ?? 0.0)
    }
    
    func getBMIAdvice() -> String{
        return bmi?.advice ?? "No Advice!"
    }
    
    func getBMIColor() -> UIColor{
        return bmi?.color ?? UIColor.white
    }
}
