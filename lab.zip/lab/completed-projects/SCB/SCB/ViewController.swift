//
//  ViewController.swift
//  SCB
//
//  Created by Jared Chen on 2024/3/15.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

