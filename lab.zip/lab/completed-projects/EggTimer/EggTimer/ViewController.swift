//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var msgLabel: UILabel!
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    //Dictionary
    let eggTimes = ["Soft": 300, "Medium": 480, "Hard": 720]
    var secondsRemaining = 0
    var totalTime = 0
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        progressBar.progress = 0.0
    }

    @IBAction func hardnessSelected(_ sender: UIButton) {
        timer.invalidate()
        progressBar.progress = 0.0
        
        let hardness = sender.currentTitle!
        
        msgLabel.text = "\(hardness) Egg Selected"
        
        totalTime = eggTimes[hardness]!
        print("Time spent to cook \(hardness) egg is \(totalTime) minutes." )
        secondsRemaining = totalTime
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer(){
        if secondsRemaining > 0 {
            print("\(secondsRemaining) seconds...")
            secondsRemaining -= 1
            progressBar.progress = Float(totalTime - secondsRemaining) / Float(totalTime)
        }else{
            msgLabel.text = "Done!"
            progressBar.progress = 1.0
        }
    }
}
